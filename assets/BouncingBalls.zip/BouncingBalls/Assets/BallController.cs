﻿using UnityEngine;
using System.Collections;
using System.IO;

public class BallController : MonoBehaviour {

	float x,y,z;
	Vector3 pos;
	Vector3 velocity;
	string LOG_FILE_NAME;
	StreamWriter file;

	// Use this for initialization
	void Start () {

		// Generate random start position
		x = Random.Range (-9, 9);
		y = Random.Range (1, 12);
		z = Random.Range (-9, 9);

		pos = new Vector3 (x, y, z);
		transform.position = pos;

		// Generate random velocity
		rigidbody.velocity = new Vector3 (Random.Range (1,10),Random.Range (1,10),Random.Range (1,10));

		switch (transform.name) {
		case "Red":
			LOG_FILE_NAME = "RedBallLogFile.txt";
			break;
		case "Yellow":
			LOG_FILE_NAME = "YellowBallLogFile.txt";
			break;
		case "Blue":
			LOG_FILE_NAME = "BlueBallLogFile.txt";
			break;
		default:
			LOG_FILE_NAME = "UnnamedBallLogFile.txt";
			break;
		}

		// Begin the logging process
		InvokeRepeating ("LogBallPosition", 0, 1);
	}

	void OnGUI() {
		GUI.color = Color.black;

		// Find each ball object with a Tag of player and has a color name
		foreach (GameObject ball in GameObject.FindGameObjectsWithTag("Player")) {
			if(ball.name == "Red" || ball.name == "Yellow" || ball.name == "Blue") {
				// Display the position of the ball
				GUILayout.Label (ball.name + " Ball Position: " + ball.transform.position.ToString());
			}
		}
	}

	void LogBallPosition () {
		string position = transform.name + " Ball Position: " + transform.position.ToString () + "\n";
		File.AppendAllText (LOG_FILE_NAME, position);
	}
}
