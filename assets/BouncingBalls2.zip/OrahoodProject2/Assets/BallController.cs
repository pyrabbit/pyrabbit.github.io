﻿using UnityEngine;
using System.Collections;
using System.IO;

public class BallController : MonoBehaviour {
	
	float x,y,z;
	Vector3 pos;
	Vector3 velocity;
	string LOG_FILE_NAME;
	StreamWriter file;
	
	// Use this for initialization
	void Start () {

		// Generate random start position
		x = Random.Range (-1f, 1f);
		y = Random.Range (-1f, 1f);
		z = Random.Range (-1f, 1f);

		pos = new Vector3 (x, y, z);
		transform.position = transform.TransformPoint(pos * 5.0f);
		
		// Generate random velocity
		rigidbody.velocity = new Vector3 (Random.Range (1,10),Random.Range (1,10),Random.Range (1,10));
		
		switch (transform.name) {
		case "Red":
			LOG_FILE_NAME = "RedBallLogFile.txt";
			break;
		case "Yellow":
			LOG_FILE_NAME = "YellowBallLogFile.txt";
			break;
		case "Green":
			LOG_FILE_NAME = "GreenBallLogFile.txt";
			break;
		default:
			LOG_FILE_NAME = "UnnamedBallLogFile.txt";
			break;
		}
		
		// Begin the logging process
		InvokeRepeating ("LogBallPosition", 0, 1);
		InvokeRepeating ("ChangeGravity", 0, 5);
	}
	
	void OnGUI() {
		GUI.color = Color.black;
		GUILayout.Label ("World Gravity: " + Physics.gravity);
		// Find each ball object with a Tag of player and has a color name
		foreach (GameObject ball in GameObject.FindGameObjectsWithTag("Player")) {
			if(ball.name == "Red" || ball.name == "Yellow" || ball.name == "Green") {
				// Display the position of the ball
				GUILayout.Label (ball.transform.parent.name + ": " + ball.name + " Ball Position: " + ball.transform.position.ToString() + 
				                 "\nBall Velocity: " + ball.GetComponent<Rigidbody>().velocity );
			}
		}
	}
	
	void LogBallPosition () {
		string position = transform.parent.name + ": " + transform.name + " Ball Position: " + transform.position.ToString () +
			" Ball Velocity: " + transform.GetComponent<Rigidbody>().velocity + " World Gravity: " + Physics.gravity + "\n";
		File.AppendAllText (LOG_FILE_NAME, position);
	}

	void ChangeGravity() {
		float gx, gy, gz;
		gx = Random.Range(-10,10);
		gy = Random.Range(-10,10);
		gz = Random.Range(-10,10);
		Physics.gravity = new Vector3 (gx, gy, gz);
	}
}
